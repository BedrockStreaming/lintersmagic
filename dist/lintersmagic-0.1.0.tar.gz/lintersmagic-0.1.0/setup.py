# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['lintersmagic']
install_requires = \
['ipython==7.17', 'pycodestyle==2.8.0']

setup_kwargs = {
    'name': 'lintersmagic',
    'version': '0.1.0',
    'description': 'A package to include linters in Databricks notebooks: flake8 and pycodestyle',
    'long_description': None,
    'author': 'Bedrock streaming',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
